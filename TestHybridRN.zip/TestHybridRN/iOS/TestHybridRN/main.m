//
//  main.m
//  TestHybridRN
//
//  Created by it on 2019/5/9.
//  Copyright © 2019 房趣科技. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
