//index.js
//获取应用实例
const app = getApp()

Page({

  data: {
    array: [{
        name: '张三丰',
        phoneNo: '1674379384',
        zhiwei: '资深置业顾问',
        adderss: '下城区新市街328号',
        agentID: '1',
      },
      {
        name: '张三丰',
        phoneNo: '1674379384',
        zhiwei: '资深置业顾问',
        adderss: '下城区新市街328号',
        agentID: '2',
      },
      {
        name: '张三丰',
        phoneNo: '1674379384',
        zhiwei: '资深置业顾问',
        adderss: '下城区新市街328号',
        agentID: '3',
      },
      {
        name: '张三丰',
        phoneNo: '1674379384',
        zhiwei: '资深置业顾问',
        adderss: '下城区新市街328号',
        agentID: '4',
      }
    ]
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    console.log("xxxxx");
  },
  
  // 列表单击跳转事件的处理函数
  clickBackAgentDetail: function(e) {
    var agentID = e.currentTarget.dataset.agentid;
    var agentName = e.currentTarget.dataset.agentname;
    wx.navigateTo({
      url: '../agentDetail/agentDetail?agentID=' + agentID + '&agentName=' + agentName,
    })
  },

})