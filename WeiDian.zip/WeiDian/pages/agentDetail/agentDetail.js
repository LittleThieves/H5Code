// pages/agentDetail/agentDetail.js

var agentID = '',
  agentName = '';

Page({
  /**
   * 页面的初始数据
   */
  data: {
    headImgUrl: '/images/icon_heade.svg',
    name: '张三丰',
    phoneNo: '1674379384',
    zhiwei: '资深置业顾问',
    adderss: '下城区新市街328号',
    lookNum: '23',
    houseNum: '50',
    rank: '朝晖人气第 1',
    selectedIdx: 0,
    selectArr: [{
        title: '在售',
      },
      {
        title: '在租',
      },
    ],
    houseInfoArr: ['刚需置业', '地铁沿线', '刚需置业', '地铁沿线', '刚需置业', ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('生命周期函数--onLoad', options);
    // wx.setNavigationBarTitle({
    //   title: options.agentName + '的微店',
    // })

    agentName = options.agentName;
    agentID = options.agentID;
  },

  /**
   * 监听房源类型选择交互方法
   */
  selectHouseType: function(e) {

    var selectedidx = e.currentTarget.dataset.selectedidx;
    var selectidx = e.currentTarget.dataset.selectidx;

    if (selectedidx == selectidx) {
      return;
    } else {
      this.setData({
        selectedIdx: selectidx,
      });
    }
    console.log('选择房源类型=========', selectedidx, selectidx);
  },

  /**
   * 监听选中房源的交互方法
   */
  disSelectedHouse: function(e) {
    wx.navigateTo({
      url: '../houseDetail/houseDetail'
    })
  },

  /**
   * 监听打电话按钮交互方法
   */
  callPhone: function(e) {

    wx.makePhoneCall({
      phoneNumber: '13396568769',
    })
  },

  /**
   * 监听存号码按钮交互方法
   */
  savePhoneNumber: function(e) {
    wx.showToast({
      title: '号码保存完毕',
    });

    wx.addPhoneContact({
      firstName: '测试名称',
      mobilePhoneNumber: '18497998332',
    })
  },

  /**
   * 监听加微信按钮交互方法
   */
  addWeChat: function(e) {
    wx.showToast({
      title: '加微信',
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    console.log('生命周期函数--onReady', agentName, agentID);
    wx.setNavigationBarTitle({
      title: agentName + '的微店',
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
    console.log('onShareAppMessage');
  }

})