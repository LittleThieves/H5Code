// pages/houseDetail/houseDetail.js

var navTitle = '',
  houseNo = '';

Page({

  /**
   * 页面的初始数据
   */
  data: {
    images: [
      'https://goss.veer.com/creative/vcg/veer/800water/veer-132322477.jpg', 'https://goss.veer.com/creative/vcg/veer/800water/veer-302382377.jpg', 'https://goss.veer.com/creative/vcg/veer/800water/veer-303816523.jpg', 'https://goss.veer.com/creative/vcg/veer/800water/veer-147802642.jpg', 'https://goss.veer.com/creative/vcg/veer/800water/veer-153100963.jpg'
    ],
    imagesIndex: '1/8',
    haveVR: true,
    haveVideo: true,
    headTextSelect: 1,
    houseInfoArr: ['刚需置业', '地铁沿线', '刚需置业', '地铁沿线', '刚需置业', '地铁沿线', '刚需置业', '地铁沿线', '刚需置业', '地铁沿线', '刚需置业',],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (this.data.haveVideo == true) {
      this.setData({
        headTextSelect: 2,
      });
    }
    if (this.data.haveVR == true) {
      this.setData({
        headTextSelect: 1,
      });
    }
    this.setData({
      imagesIndex: 1 + '/' + this.data.images.length,
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },

  bindanimationfinish: function(e) {
    console.log('滚动回调方法xx', e);
    var currentIndex = e.detail.current;
    this.setData({
      imagesIndex: currentIndex + 1 + '/' + this.data.images.length,
    });
    if (this.data.haveVR == true || this.data.haveVideo == true) {
      if (this.data.haveVR == true && this.data.haveVideo == true) {
        if (currentIndex == 0) {
          this.setData({
            headTextSelect: 1,
          });
        } else if (currentIndex == 1) {
          this.setData({
            headTextSelect: 2,
          });

        } else {
          this.setData({
            headTextSelect: 3,
          });
        }
      } else {
        if (this.data.haveVR == true) {
          if (currentIndex == 0) {
            this.setData({
              headTextSelect: 1,
            });
          } else {
            this.setData({
              headTextSelect: 3,
            });
          }
        } else {
          if (currentIndex == 1) {
            this.setData({
              headTextSelect: 2,
            });
          } else {
            this.setData({
              headTextSelect: 3,
            });
          }
        }
      }
    }
  },

})